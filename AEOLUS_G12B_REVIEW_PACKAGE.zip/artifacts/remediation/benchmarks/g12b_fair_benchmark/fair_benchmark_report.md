# AEOLUS-G12B Fair Wall-Clock Benchmark Results

- Generated at: 2026-10-12T11:15:52Z
- Platform: Windows 10
- OR-Tools: 9.15.6755

## Tiered Performance Matrix

| Scenario | Flights | Gates | Solver | Status | Feasible | Optimality | Obj Value | Incumbent | Runtime (ms) | SA Accepted | Rejection Reason |
|---|---|---|---|---|---|---|---|---|---|---|---|
| SCEN_01_MICRO_ORACLE | 4 | 4 | Greedy | FEASIBLE | True | False | 20.0 | 20.0 | 0.3 | False | N/A_STANDALONE |
| SCEN_01_MICRO_ORACLE | 4 | 4 | CP-SAT | OPTIMAL | True | True | 20.0 | 20.0 | 5.79 | False | N/A_STANDALONE |
| SCEN_01_MICRO_ORACLE | 4 | 4 | Greedy+SA | FEASIBLE | True | False | 20.0 | 20.0 | 99.87 | True | NONE |
| SCEN_01_MICRO_ORACLE | 4 | 4 | CP-SAT+SA | OPTIMAL | True | True | 20.0 | 20.0 | 103.61 | True | None |
| SCEN_02_MEDIUM_30 | 30 | 11 | Greedy | FEASIBLE | True | False | 101.2 | 101.2 | 0.92 | False | N/A_STANDALONE |
| SCEN_02_MEDIUM_30 | 30 | 11 | CP-SAT | OPTIMAL | True | True | 71.2 | 71.2 | 44.98 | False | N/A_STANDALONE |
| SCEN_02_MEDIUM_30 | 30 | 11 | Greedy+SA | FEASIBLE | True | False | 71.2 | 101.2 | 770.06 | True | NONE |
| SCEN_02_MEDIUM_30 | 30 | 11 | CP-SAT+SA | OPTIMAL | True | True | 71.2 | 71.2 | 838.72 | True | None |
| SCEN_03_THESIS_100 | 100 | 24 | Greedy | FEASIBLE | True | False | 309.3333 | 309.3333 | 3.59 | False | N/A_STANDALONE |
| SCEN_03_THESIS_100 | 100 | 24 | CP-SAT | FEASIBLE | True | False | 249.3333 | 249.3333 | 5007.83 | False | N/A_STANDALONE |
| SCEN_03_THESIS_100 | 100 | 24 | Greedy+SA | FEASIBLE | True | False | 309.3333 | 309.3333 | 2864.58 | True | NONE |
| SCEN_03_THESIS_100 | 100 | 24 | CP-SAT+SA | FEASIBLE | True | False | 249.3333 | 249.3333 | 5011.33 | True | None |
| SCEN_04_THESIS_200 | 200 | 35 | Greedy | FEASIBLE | True | False | 890.1333 | 890.1333 | 9.87 | False | N/A_STANDALONE |
| SCEN_04_THESIS_200 | 200 | 35 | CP-SAT | FEASIBLE | True | False | 660.1333 | 660.1333 | 5017.28 | False | N/A_STANDALONE |
| SCEN_04_THESIS_200 | 200 | 35 | Greedy+SA | FEASIBLE | True | False | 890.1333 | 890.1333 | 5023.04 | True | NONE |
| SCEN_04_THESIS_200 | 200 | 35 | CP-SAT+SA | FEASIBLE | True | False | 710.1333 | 710.1333 | 5037.75 | True | None |
| SCEN_05_THESIS_300 | 300 | 56 | Greedy | FEASIBLE | True | False | 1219.4667 | 1219.4667 | 17.95 | False | N/A_STANDALONE |
| SCEN_05_THESIS_300 | 300 | 56 | CP-SAT | FEASIBLE | True | False | 1059.4667 | 1059.4667 | 5000.82 | False | N/A_STANDALONE |
| SCEN_05_THESIS_300 | 300 | 56 | Greedy+SA | FEASIBLE | True | False | 1219.4667 | 1219.4667 | 5042.52 | True | NONE |
| SCEN_05_THESIS_300 | 300 | 56 | CP-SAT+SA | FEASIBLE | True | False | 1219.4667 | 1219.4667 | 5031.02 | True | None |
